Rails.application.routes.draw do
 get 'top' => 'homes#top'
 

  # ---- 下記1行を追加してください ---- #
 post 'books' => 'books#create'

  # ---- 下記1行を追加してください ---- #
 get 'books' => 'books#index'
 get 'books/:id/show' => 'books#show' ,as: 'book'
 get 'books/:id/edit'=> 'books#edit' ,as: 'edit_book'
 post 'books/:id/show' => 'books#show'
 post 'books/:id/edit' => 'books#edit' 
 delete 'books/:id' => 'books#destroy', as: 'destroy_book'
 patch 'books/:id/show' => 'books#update', as: 'update_book'
end
